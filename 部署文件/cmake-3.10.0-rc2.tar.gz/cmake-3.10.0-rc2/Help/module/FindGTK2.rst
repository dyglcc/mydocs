.. cmake-module:: ../../Modules/FindGTK2.cmake
